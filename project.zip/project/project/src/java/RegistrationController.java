import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserDataServlet
 */
public class RegistrationController extends HttpServlet {

 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  // TODO Auto-generated method stub
  response.setContentType("text/html");
  PrintWriter out = response.getWriter();
  String name = request.getParameter("fullname");
  String address = request.getParameter("address");
  String phone = request.getParameter("phone");
  String gender = request.getParameter("gender");
  String email = request.getParameter("email");
  String password = request.getParameter("password");
  
 
  // validate given input
  if (name.isEmpty() || address.isEmpty() || phone.isEmpty()|| gender.isEmpty() || email.isEmpty() || password.isEmpty()) {
   RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
   out.println("fields inserted");
   rd.include(request, response);
  } else {
   
   try {
        Connection con;
     String driver = "org.apache.derby.jdbc.EmbeddedDriver";
    String dbName = "project";
    String connectionURL = "jdbc:derby://localhost:1527/project/";
   
    Class.forName(driver);

    con = DriverManager.getConnection(connectionURL);

   

       try (PreparedStatement ps = con.prepareStatement("insert into customer(name,address,phone,gender,email,password) values (?,?,?,?,?,?)") // generates sql query
       ) {
           ps.setString(1, name);
           ps.setString(2, address);
           ps.setString(3, phone);
           ps.setString(4, gender);
           ps.setString(5, email);
           ps.setString(6, password);
           
           
           ps.executeUpdate();
           System.out.println("successfuly inserted");
       }
    con.close();
   } catch (ClassNotFoundException | SQLException e) {
   }
   RequestDispatcher rd = request.getRequestDispatcher("success_register.jsp");
   rd.forward(request, response);
  }
 }
}
