
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserDataServlet
 */
public class RegistrationController_driver extends HttpServlet {

 @Override
 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  // TODO Auto-generated method stub
  response.setContentType("text/html");
  PrintWriter out = response.getWriter();
  //String registration = request.getParameter("registration");
  String name = request.getParameter("name");
  String address = request.getParameter("address");
  String phone = request.getParameter("phone");
  String email = request.getParameter("email");
  String password = request.getParameter("password");
 
  // validate given input
  if ( name.isEmpty() ||  address.isEmpty() || phone.isEmpty() || email.isEmpty() || password.isEmpty()) {
   RequestDispatcher rd = request.getRequestDispatcher("registration_driver.jsp");
   out.println("fields inserted");
  
   rd.include(request, response);
  } else {
   // inserting data into mysql database 
   // create a test database and student table before running this to create table
   
   try {
        Connection con;
     String driver = "org.apache.derby.jdbc.EmbeddedDriver";
    String dbName = "project";
    String connectionURL = "jdbc:derby://localhost:1527/project";
   
    Class.forName(driver);

    con = DriverManager.getConnection(connectionURL);

   
    PreparedStatement ps = con.prepareStatement("insert into drivers(name,address,phone,email,password) values (?,?,?,?,?)"); // generates sql query

   
    ps.setString(1, name);
    ps.setString(2, address);
    ps.setString(3, phone);
    ps.setString(4, email);
    ps.setString(5, password);
    
    ps.executeUpdate(); 
    System.out.println("your data is successfull");
    ps.close();
    con.close();
   } catch (ClassNotFoundException | SQLException e) {
   }
   RequestDispatcher rd = request.getRequestDispatcher("registration_driver.jsp");
   rd.forward(request, response);
  }
 }
}
