/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class check_Driver {
      static Connection conn;
     public static boolean checkUser(String email,String password) 
     {
      boolean st =false;
      try{

    String driver = "org.apache.derby.jdbc.EmbeddedDriver";
    String dbName = "project";
    String connectionURL = "jdbc:derby://localhost:1527/project/";
    //String createString = "select * from register where email=? and pass=?";
    Class.forName(driver);

    conn = DriverManager.getConnection(connectionURL);

     PreparedStatement ps =conn.prepareStatement
                             ("select * from drivers where email=? and password=?");
         ps.setString(1, email);
         ps.setString(2, password);
         ResultSet rs =ps.executeQuery();
         st = rs.next();
        
      }catch(ClassNotFoundException | SQLException e)
      {
      }
         return st;                 
  }   
}
