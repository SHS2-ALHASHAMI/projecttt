/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author neha
 */
public class Login {
    private String email;
    private String password;

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }
    
    
    public int store() throws ClassNotFoundException, SQLException{
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        String url = "jdbc:derby://localhost:1527/project;create=true;user=root;password=0000";
        Connection con =(Connection) DriverManager.getConnection(url);
        PreparedStatement ps = (PreparedStatement) con.prepareStatement("insert into ADMIN (email,password) values(?,?)");
        
        ps.setString(1,email);
        ps.setString(2,password);
        
        int a = ps.executeUpdate();
        if (a==1 ){
            return a;
            
        }
        else {
            return a;
        }
        
        
        
        
    }
    
    
}
