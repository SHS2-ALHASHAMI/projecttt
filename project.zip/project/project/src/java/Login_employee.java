import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



public class Login_employee extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String type =  request.getParameter("employee");
        String email = request.getParameter("email");
        String pass = request.getParameter("password");
        
        if(type.equals("Driver")){
            
        
            if(check_Driver.checkUser(email, pass))
            {
            
               HttpSession session = request.getSession(true); 
                                            
                session.setAttribute("email", email);
                session.setMaxInactiveInterval(50); 
         
                
         
         
                RequestDispatcher rs = request.getRequestDispatcher("driver.jsp");
                rs.forward(request, response);
            }
            else
            {
           out.println("Username or Password incorrect");
           RequestDispatcher rs = request.getRequestDispatcher("employee.html");
           rs.include(request, response);
             }
        }
        if(type.equals("Admin")){
            
            if(check_Admin.checkUser(email, pass))
            {
               HttpSession session = request.getSession(true); 
                                      
                session.setAttribute("email", email);
                session.setMaxInactiveInterval(20); 
         
                RequestDispatcher rs = request.getRequestDispatcher("admin.jsp");
                rs.forward(request, response);
            }
            else
            {
           out.println("Username or Password incorrect");
           RequestDispatcher rs = request.getRequestDispatcher("employee.html");
           rs.include(request, response);
             }
       
        }
    }
}