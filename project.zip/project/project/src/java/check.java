/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.*;

/**
 *
 * @author neha
 */


public class check
 {
      static Connection conn;
     public static boolean checkUser(String email,String password) 
     {
      boolean st =false;
      try{
/*
	 //loading drivers for mysql
         */
          
          
    String driver = "org.apache.derby.jdbc.EmbeddedDriver";
    String dbName = "project";
    String connectionURL = "jdbc:derby://localhost:1527/project/";
    //String createString = "select * from register where email=? and pass=?";
    Class.forName(driver);

    conn = DriverManager.getConnection(connectionURL);

     PreparedStatement ps =conn.prepareStatement
                             ("select * from customer where email=? and password=?");
         ps.setString(1, email);
         ps.setString(2, password);
         ResultSet rs =ps.executeQuery();
         st = rs.next();
        
      }catch(Exception e)
      {
          e.printStackTrace();
      }
         return st;                 
  }   
}
